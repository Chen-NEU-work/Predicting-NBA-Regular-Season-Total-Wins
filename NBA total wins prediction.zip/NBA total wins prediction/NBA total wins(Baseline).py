import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score

from sklearn.linear_model import LinearRegression, Ridge
from sklearn.neighbors import KNeighborsRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor

# ===========================
# 1. Load data
# ===========================
wins_df = pd.read_csv("NBA_Wins_2017_2022.csv")
wins_df["Season"] = wins_df["Season"].astype(int)

last10_df = pd.read_csv("NBA_Last10_2017_2022.csv")
last10_df["Season"] = last10_df["Season"].astype(int)

perf_df = pd.read_csv("NBA_TeamPerformance_2017_2022.csv")
perf_df["Season"] = perf_df["Season"].astype(int)

per_df = pd.read_csv("NBA_players_PER_2017_2022.csv")
per_df["Season"] = per_df["Season"].astype(int)
per_df["PER"] = pd.to_numeric(per_df["PER"], errors="coerce")

# ===========================
# 2. Feature engineering
# ===========================
avg_per = (
    per_df.groupby(["Season", "Team"])["PER"]
    .mean()
    .reset_index()
    .rename(columns={"PER": "Avg_PER"})
)

# ===========================
# 3. Merge data
# ===========================
base_df = (
    wins_df.merge(last10_df, on=["Season", "Team"], how="left")
           .merge(perf_df,   on=["Season", "Team"], how="left")
           .merge(avg_per,   on=["Season", "Team"], how="left")
)
base_df = base_df.fillna(base_df.mean(numeric_only=True))

# ===========================
# 4. Set target
# ===========================
future_wins = wins_df[["Team", "Season", "Wins"]].copy()
future_wins["Season"] -= 1
future_wins = future_wins.rename(columns={"Wins": "NextWins"})

data = base_df.merge(future_wins, on=["Team", "Season"], how="inner")

# ===========================
# 5. Perpare features and labels
# ===========================
feature_cols = ["Wins", "Last10", "Avg_PER", "PTS", "REB", "AST", "TOV", "STL", "BLK"]
X = data[feature_cols]
y = data["NextWins"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

# ===========================
# 6. Build model
# ===========================
models = {
    "Linear Regression": LinearRegression(),
    "k-Nearest Neighbors": KNeighborsRegressor(n_neighbors=5),
    "Ridge Regression": Ridge(alpha=1.0),
    "Random Forest": RandomForestRegressor(n_estimators=300, random_state=42),
    "Gradient Boosting": GradientBoostingRegressor(random_state=42),
}

# ===========================
# 7. Training and evaluation
# ===========================
best_model_name = ""
best_model = None
best_r2 = -float("inf")
best_rmse = float("inf")

print("=== Model Evaluation Results ===")
print(f"{'Model':<25} {'R2':<10} {'RMSE':<10}")
print("-" * 45)

for name, model in models.items():
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    preds_clipped = np.clip(preds, 0, 82)
    
    rmse = np.sqrt(mean_squared_error(y_test, preds_clipped))
    r2 = r2_score(y_test, preds_clipped)
    
    
    print(f"{name:<25} {r2:<10.3f} {rmse:<10.3f}")
    
    if r2 > best_r2:
        best_r2 = r2
        best_rmse = rmse
        best_model = model
        best_model_name = name

print("-" * 45)

print(f"🏆 Best Model: {best_model_name}")
print(f"🏆 R2 Score: {best_r2:.3f}")
print(f"🏆 RMSE: {best_rmse:.3f}")

# ===========================
# 8. Predict 2023
# ===========================
season_2022 = base_df[base_df["Season"] == 2022].copy()

if not season_2022.empty:
    X_2022 = season_2022[feature_cols]
    X_2022_scaled = scaler.transform(X_2022)

    pred_2023 = best_model.predict(X_2022_scaled)
    pred_2023 = np.clip(pred_2023, 0, 82)

    
    season_2022["Pred_Wins_2023"] = np.round(pred_2023).astype(int)

    result_df = season_2022[["Team", "Pred_Wins_2023"]].sort_values(by="Pred_Wins_2023", ascending=False)
    
    print("\n=== 2023 NBA predict wins ===")
    print(result_df.to_string(index=False))
else:
    print("Can't predict.")